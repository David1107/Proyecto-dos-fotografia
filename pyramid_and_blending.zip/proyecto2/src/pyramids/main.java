package pyramids;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Size;

import org.opencv.imgcodecs.*;
import org.opencv.imgproc.Imgproc;

public class main {
   public static void main( String[] args ) {
   
      try{
      
         System.loadLibrary( Core.NATIVE_LIBRARY_NAME );
         /*
         Mat alto = Imgcodecs.imread("data/sobel/h_sobel.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
         Mat bajo = Imgcodecs.imread("data/media/g_media.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
         
         double a = 1.0;
         double b = 0.1;
         Mat dst = alto;
         
         Core.addWeighted(alto, a, bajo, b, 0, dst);
         Imgcodecs.imwrite("hybrid12.jpg", dst);
         
         System.out.println("termine");*/
         
         Mat source = Imgcodecs.imread("data/result/hybrid12.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
         
         Mat destination = new Mat(source.rows()*2,source.cols()*2, source.type());
         destination = source;

         Imgproc.pyrDown(source, destination);
         //Imgproc.pyrUp(source, destination);
         Imgcodecs.imwrite("pyrDown.jpg", destination);
         
         Mat sourceTwo = Imgcodecs.imread("pyrDown.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
         
         Mat destinationTwo = new Mat(sourceTwo.rows()/2,sourceTwo.cols()/2, sourceTwo.type());
         destinationTwo = sourceTwo;
         
         Imgproc.pyrDown(sourceTwo, destinationTwo);
         Imgcodecs.imwrite("pyrDownTwo.jpg", destinationTwo);
         
         Mat sourceThree = Imgcodecs.imread("pyrDownTwo.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
         Mat destinationThree = new Mat(sourceThree.rows()/2,sourceThree.cols()/2, sourceThree.type());
         destinationThree = sourceThree;
         
         Imgproc.pyrDown(sourceThree, destinationThree);
         Imgcodecs.imwrite("pyrDownThree.jpg", destinationThree);
         
         System.out.println("termine");
         
         
      }catch (Exception e){ 
         System.out.println("error: " + e.getMessage());
      }
      
   }
   
}
